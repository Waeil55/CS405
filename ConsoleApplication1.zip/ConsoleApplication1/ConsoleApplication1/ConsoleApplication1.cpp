#include <iostream>
#include <stdexcept>  // For standard exceptions

// Custom exception class derived from std::exception
class CustomException : public std::exception {
public:
    const char* what() const noexcept override {
        return "Custom exception: A custom exception derived from std::exception has been thrown.";
    }
};

bool do_even_more_custom_application_logic() {
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Throwing a standard exception to demonstrate exception handling
    throw std::out_of_range("Error: Out of range exception thrown in do_even_more_custom_application_logic.");

    return true;
}

void do_custom_application_logic() {
    try {
        std::cout << "Running Custom Application Logic." << std::endl;

        // Calling a function that may throw a standard exception
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& ex) {
        // Handling any standard exception thrown in the function
        std::cerr << "Standard exception caught in custom application logic: " << ex.what() << std::endl;
    }

    // Throwing a custom exception after handling the previous standard exception
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den) {
    if (den == 0.0f) {
        // Throwing an exception for division by zero
        throw std::domain_error("Error: Division by zero is not allowed.");
    }

    return num / den;
}

void do_division() noexcept {
    try {
        float numerator = 10.0f;
        float denominator = 0.0f;

        // Attempting to divide by zero, which will throw an exception
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::domain_error& ex) {
        // Handling only the divide-by-zero exception
        std::cerr << "Exception caught in do_division: " << ex.what() << std::endl;
    }
}
int main() {
    std::cout << "Exceptions Tests!" << std::endl;

    try {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& ex) {
        std::cerr << "Custom exception caught in main: " << ex.what() << std::endl;
    }
    catch (const std::exception& ex) {
        std::cerr << "Standard exception caught in main: " << ex.what() << std::endl;
    }
    catch (...) {
        std::cerr << "An unknown exception was caught in main." << std::endl;
    }

    // Pause before exiting
    std::cout << "Press Enter to continue...";
    std::cin.get();  // Waits for user input

    return 0;
}
