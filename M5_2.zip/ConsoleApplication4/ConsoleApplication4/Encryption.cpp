#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <fstream>
#include <string>
#include <cassert>
#include <ctime>
#include <iomanip>

// Encrypt or decrypt a source string using XOR with the provided key
std::string encrypt_decrypt(const std::string& source, const std::string& key) {
    const auto key_length = key.length();
    const auto source_length = source.length();
    assert(key_length > 0 && source_length > 0);

    std::string output = source;
    for (size_t i = 0; i < source_length; ++i) {
        output[i] = source[i] ^ key[i % key_length];
    }
    assert(output.length() == source_length);
    return output;
}

// Read a file into a string
std::string read_file(const std::string& filename) {
    std::ifstream file(filename);
    if (!file) {
        std::cerr << "Error: Unable to open file " << filename << "\n";
        return "";
    }
    return std::string((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
}

// Extract student name from the string data
std::string get_student_name(const std::string& string_data) {
    size_t pos = string_data.find('\n');
    return (pos != std::string::npos) ? string_data.substr(0, pos) : "";
}

// Save data to a file with specific format
void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data) {
    std::ofstream file(filename);
    if (!file) {
        std::cerr << "Error: Unable to write to file " << filename << "\n";
        return;
    }

    std::time_t t = std::time(nullptr);
    std::tm tm;
#if defined(_MSC_VER)
    localtime_s(&tm, &t);
#else
    localtime_r(&t, &tm);
#endif

    file << student_name << "\n"
        << std::put_time(&tm, "%Y-%m-%d") << "\n"
        << key << "\n"
        << data;
}
int main() {
    std::cout << "Encryption Decryption Test!" << std::endl;

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrypteddatafile.txt";
    const std::string key = "password";

    std::cout << "Attempting to read file: " << file_name << std::endl;

    // Read the source file
    const std::string source_string = read_file(file_name);
    if (source_string.empty()) {
        std::cerr << "Error: Input file is empty or couldn't be read.\n";
        return 1;
    }

    std::cout << "File read successfully. Content length: " << source_string.length() << std::endl;

    // Get the student name from the data file
    const std::string student_name = get_student_name(source_string);
    if (student_name.empty()) {
        std::cerr << "Error: Couldn't extract student name from the file.\n";
        return 1;
    }

    std::cout << "Extracted student name: " << student_name << std::endl;

    // Encrypt source string with key
    std::cout << "Encrypting the source string..." << std::endl;
    const std::string encrypted_string = encrypt_decrypt(source_string, key);
    std::cout << "Encryption complete. Encrypted length: " << encrypted_string.length() << std::endl;

    // Save encrypted string to file
    std::cout << "Saving encrypted data to file: " << encrypted_file_name << std::endl;
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // Decrypt encrypted string with key
    std::cout << "Decrypting the encrypted string..." << std::endl;
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);
    std::cout << "Decryption complete. Decrypted length: " << decrypted_string.length() << std::endl;

    // Save decrypted string to file
    std::cout << "Saving decrypted data to file: " << decrypted_file_name << std::endl;
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;

    // Verify that the decryption process worked correctly
    if (source_string == decrypted_string) {
        std::cout << "Encryption and decryption successful: The decrypted string matches the original source string." << std::endl;
    }
    else {
        std::cerr << "Error: The decrypted string does not match the original source string." << std::endl;
        return 1;
    }

    std::cout << "Program completed successfully." << std::endl;
    return 0;
}
