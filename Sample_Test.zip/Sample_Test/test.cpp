#include "pch.h"  // Include precompiled header if needed
#include <gtest/gtest.h>
#include <vector>
#include <memory>
#include <stdexcept>
#include <cstdlib>
#include <ctime>

// The global test environment setup and tear down
class Environment : public ::testing::Environment {
public:
    ~Environment() override {}

    void SetUp() override {
        srand(time(nullptr));
    }

    void TearDown() override {}
};

// Create the test class to house shared data between tests
class CollectionTest : public ::testing::Test {
protected:
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override {
        collection.reset(new std::vector<int>);
    }

    void TearDown() override {
        collection->clear();
        collection.reset(nullptr);
    }

    // Helper function to add entries to the collection
    void add_entries(int count) {
        if (count <= 0) {
            throw std::invalid_argument("Count must be greater than 0");
        }
        for (auto i = 0; i < count; ++i) {
            collection->push_back(rand() % 100);
        }
    }
};

// Test that a collection is created and not null
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull) {
    ASSERT_TRUE(collection);
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created
TEST_F(CollectionTest, IsEmptyOnCreate) {
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// Test adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector) {
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    EXPECT_FALSE(collection->empty());
    EXPECT_EQ(collection->size(), 1);
}

// Test adding five values to the collection
TEST_F(CollectionTest, CanAddFiveValuesToVector) {
    add_entries(5);
    EXPECT_EQ(collection->size(), 5);
}

// Test that max size is greater than or equal to the size of the collection
TEST_F(CollectionTest, MaxSizeGreaterThanOrEqualToSize) {
    collection->clear();
    EXPECT_GE(collection->max_size(), collection->size());

    std::vector<int>::size_type sizes[] = { 1, 5, 10 };
    for (auto size : sizes) {
        collection->clear();
        add_entries(size);
        EXPECT_GE(collection->max_size(), collection->size());
    }
}

// Test that capacity is greater than or equal to size for various entry counts
TEST_F(CollectionTest, CapacityGreaterThanOrEqualToSize) {
    std::vector<int>::size_type sizes[] = { 0, 1, 5, 10 };
    for (auto size : sizes) {
        collection->clear();

        if (size > 0) {
            add_entries(size);
        }

        EXPECT_GE(collection->capacity(), collection->size());
    }
}

// Test resizing increases the collection size
TEST_F(CollectionTest, ResizeIncreasesCollection) {
    collection->resize(5);
    EXPECT_EQ(collection->size(), 5);
}

// Test resizing decreases the collection size
TEST_F(CollectionTest, ResizeDecreasesCollection) {
    add_entries(10);
    collection->resize(5);
    EXPECT_EQ(collection->size(), 5);
}

// Test resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeToZero) {
    add_entries(10);
    collection->resize(0);
    EXPECT_EQ(collection->size(), 0);
    EXPECT_TRUE(collection->empty());
}

// Test clearing the collection
TEST_F(CollectionTest, ClearErasesCollection) {
    add_entries(5);
    collection->clear();
    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0);
}

// Test erasing a range of elements
TEST_F(CollectionTest, EraseRange) {
    add_entries(5);
    collection->erase(collection->begin(), collection->end());
    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0);
}

// Test reserving capacity
TEST_F(CollectionTest, ReserveIncreasesCapacity) {
    std::size_t initial_capacity = collection->capacity();
    collection->reserve(initial_capacity + 10);
    EXPECT_GT(collection->capacity(), initial_capacity);
    EXPECT_EQ(collection->size(), 0);
}

// Negative Test: Accessing out-of-bounds index should throw an exception
TEST_F(CollectionTest, ThrowsExceptionWhenOutOfBounds) {
    add_entries(5);
    EXPECT_THROW(collection->at(10), std::out_of_range);
}

// Custom Positive Test: Verify front() returns the first element
TEST_F(CollectionTest, FrontReturnsFirstElement) {
    add_entries(1);
    EXPECT_EQ(collection->front(), collection->at(0));
}

// Custom Negative Test: Verify that adding negative entries throws an exception
TEST_F(CollectionTest, AddNegativeEntriesFailsWithException) {
    EXPECT_THROW(add_entries(-1), std::invalid_argument);
}

int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
